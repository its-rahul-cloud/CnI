document.addEventListener('DOMContentLoaded', () => {

    // --- Intersection Observer for Slide Animations ---
    const slides = document.querySelectorAll('.slide');

    const slideObserverOptions = {
        root: null, // Use the viewport as the root
        rootMargin: '0px',
        threshold: 0.4 // Trigger when 40% of the slide is visible
    };

    const slideObserverCallback = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Add 'is-visible' class when slide enters viewport
                entry.target.classList.add('is-visible');
                // Optional: Unobserve after it becomes visible if you don't need it to re-animate
                // observer.unobserve(entry.target);
            } else {
                // Optional: Remove class if you want elements to fade out when scrolled away
                // entry.target.classList.remove('is-visible');
            }
        });
    };

    const slideObserver = new IntersectionObserver(slideObserverCallback, slideObserverOptions);

    slides.forEach(slide => {
        slideObserver.observe(slide);
    });

    // --- Keyboard Navigation ---
    const presentationContainer = document.getElementById('presentation-container');

    const navigateSlides = (direction) => {
        const currentScroll = presentationContainer.scrollTop;
        const viewportHeight = presentationContainer.clientHeight; // Use container height

        let targetSlide = null;

        if (direction === 'down') {
            // Find the next slide that starts below the current view top
            for (let i = 0; i < slides.length; i++) {
                if (slides[i].offsetTop > currentScroll + 10) { // +10 to avoid rounding issues
                    targetSlide = slides[i];
                    break;
                }
            }
        } else if (direction === 'up') {
            // Find the previous slide (the last one whose top is above the current top)
             for (let i = slides.length - 1; i >= 0; i--) {
                if (slides[i].offsetTop < currentScroll - 10) { // -10 threshold
                    targetSlide = slides[i];
                    break;
                }
            }
             // If already near the top, go to the very first slide
             if (currentScroll > 0 && !targetSlide) {
                 targetSlide = slides[0];
             }
        }

        if (targetSlide) {
            // Use the container's scroll method
             presentationContainer.scrollTo({
                top: targetSlide.offsetTop,
                behavior: 'smooth'
            });
        } else if (direction === 'up' && currentScroll <= 0) {
             // Already at the top, do nothing or maybe loop to bottom? (Keep simple for now)
             console.log("Already at the top");
        } else if (direction === 'down' && !targetSlide) {
             // Already at the bottom (no next slide found)
             console.log("Already at the bottom");
        }
    };

    document.addEventListener('keydown', (event) => {
        // Check if focus is on an input field, if so, ignore navigation keys
        if (event.target.tagName === 'INPUT' || event.target.tagName === 'TEXTAREA') {
            return;
        }

        switch (event.key) {
            case 'ArrowDown':
            case 'PageDown':
            case ' ': // Space bar also goes down
                 event.preventDefault(); // Prevent default space bar scroll
                navigateSlides('down');
                break;
            case 'ArrowUp':
            case 'PageUp':
                 event.preventDefault(); // Prevent default arrow scroll if necessary
                navigateSlides('up');
                break;
        }
    });

    // --- Optional: Smooth scroll for any internal links (if you add them later) ---
    // document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    //     anchor.addEventListener('click', function (e) {
    //         e.preventDefault();
    //         const targetId = this.getAttribute('href');
    //         const targetElement = document.querySelector(targetId);
    //         if(targetElement) {
    //              presentationContainer.scrollTo({
    //                  top: targetElement.offsetTop,
    //                  behavior: 'smooth'
    //              });
    //         }
    //     });
    // });

}); // End DOMContentLoaded
